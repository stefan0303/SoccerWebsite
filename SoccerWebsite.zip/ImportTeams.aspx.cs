﻿using Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ImportTeams : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        //Make the dropDown List from Enum Class order by colour name
        DropDownListPrimaryKitColour.DataSource = Enumeration.GetAll<EnumColor>().OrderBy(c => c.Value);
        DropDownListPrimaryKitColour.DataTextField = "Value";
        DropDownListPrimaryKitColour.DataValueField = "Key";

        //Make the dropDown List from Enum Class order by colour name
        DropDownListSecondaryKitColour.DataSource = Enumeration.GetAll<EnumColor>().OrderBy(c => c.Value);
        DropDownListSecondaryKitColour.DataTextField = "Value";
        DropDownListSecondaryKitColour.DataValueField = "Key";

        DropDownListPrimaryKitColour.DataBind();
        DropDownListSecondaryKitColour.DataBind();

        using (soccerContext context = new soccerContext())
        {
            //Make the dropDown List from Competitions Data
            DropDownCompetitions.DataSource = context.Competitions.OrderBy(c => c.Name).ToList();
            DropDownCompetitions.DataTextField = "name";
            DropDownCompetitions.DataBind();

            //Make the dropDown List from Town Data
            DropDownTowns.DataSource = context.Towns.OrderBy(c => c.Name).ToList();
            DropDownTowns.DataTextField = "name";
            DropDownTowns.DataBind();


            //Get The new Team Name and import it to data
        }
        if (Request.Form.Count > 0)
        {
            string nameOfTeam = Request.Form["team"];
            string[] controls = Request.Form.AllKeys.Reverse().Take(5).ToArray();
            if (nameOfTeam != null && nameOfTeam != "")
            {//
                string competition = Request.Form["ctl00$MainContent$DropDownCompetitions"];
                string town = Request.Form["ctl00$MainContent$DropDownTowns"];
                //there can be the same primary and secondary kit colour
                string primaryKitColour = Request.Form["ctl00$MainContent$DropDownListPrimaryKitColour"];
                string secondaryKitColour = Request.Form["ctl00$MainContent$DropDownListSecondaryKitColour"];
                //ToDO if Any is blanc like Select Competition or Select Town Throw Exeption
                string[] dataArgs = new string[] { nameOfTeam, competition, town, primaryKitColour, secondaryKitColour };

                CommandDispatcher commandDispatcher = new CommandDispatcher("team", dataArgs);

            }
            else
            {
                throw new ArgumentException("The Team Name is null or Empty");//ToDo this is not for here
            }
        }


    }

}