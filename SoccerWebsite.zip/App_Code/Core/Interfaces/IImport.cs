﻿
public interface IImport
{
     void Execute();
}