﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SoccerWebsite;


public class CommandDispatcher
{
    public CommandDispatcher(string typeOfData, string dataArgs)
    {
        //soccerContext context = new soccerContext();
        //using (context)
        //{
        //    switch (typeOfData)
        //    {
        //        //case "country":

        //        //    CountryDataImportData(dataArgs, context);
        //        //    break;
        //        //case "competition":
        //        //    CompetitionDataImport(dataArgs, context);
        //        //    break;
        //        case "colour":
        //            ImportColour importColours = new ImportColour(dataArgs);
        //            importColours.Execute();
        //            break;
        //    }

        //    context.SaveChanges();
        //}
    }

   

}