﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SoccerWebsite;

public class ImportColour : System.Web.UI.Page
{
    private string data;
    public ImportColour(string dataArgs)
    {
        this.data = dataArgs;
    }
    public void Execute()
    {
       

        
    }
}