﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Games : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        using (soccerContext context = new soccerContext())
        {
            //Competitions Drop Down
           
            DropDownListCompetitions.DataSource = context.Competitions.OrderBy(c => c.Name).ToList();
            DropDownListCompetitions.DataTextField = "name";     
            DropDownListCompetitions.DataBind();

            //Teams Drop Down 
            //ToDo show only Teams From Competition Drop Down Menu!!!
          
            DropDownListHomeTeam.DataSource = context.Teams.OrderBy(c => c.Name).ToList();
            DropDownListHomeTeam.DataTextField = "name";
            DropDownListHomeTeam.DataBind();

      
            DropDownListAwayTeam.DataSource = context.Teams.OrderBy(c => c.Name).ToList();
            DropDownListAwayTeam.DataTextField = "name";
            DropDownListAwayTeam.DataBind();

            // Team Goals
            DropDownListHomeTeamGoals.Items.Clear();
            DropDownListHomeTeamGoals.Items.Add(string.Empty);//!!
            DropDownListHomeTeamGoals.Items.AddRange(Enumerable.Range(0, 21).Select(m => new ListItem(m.ToString())).ToArray());
            DropDownListHomeTeamGoals.DataTextField = "name";
            DropDownListHomeTeamGoals.DataBind();

            DropDownListAwayTeamGoals.Items.Clear();
            DropDownListAwayTeamGoals.Items.Add(string.Empty);//!!
            DropDownListAwayTeamGoals.Items.AddRange(Enumerable.Range(0, 21).Select(m => new ListItem(m.ToString())).ToArray());
            DropDownListAwayTeamGoals.DataTextField = "name";
            DropDownListAwayTeamGoals.DataBind();

        }
        //toDO Check is all data is correct
        string[] controls = Request.Form.AllKeys.Reverse().Take(5).ToArray();
        if (Request.Form.Count > 0&&!controls.Any(c=>c==""))
        {


            string competition = Request.Form["ctl00$MainContent$DropDownListCompetitions"];
            string homeTeam = Request.Form["ctl00$MainContent$DropDownListHomeTeam"];
            string awayTeam = Request.Form["ctl00$MainContent$DropDownListAwayTeam"];
            int homeTeamGoals = int.Parse(Request.Form["ctl00$MainContent$DropDownListHomeTeamGoals"]);
            int awayTeamGoals = int.Parse(Request.Form["ctl00$MainContent$DropDownListAwayTeamGoals"]);

            string dateOfGame = Request.Form["ctl00$MainContent$TxtDob"];
            DateTime date = DateTime.Parse(dateOfGame);
         
        }
    }
  

}